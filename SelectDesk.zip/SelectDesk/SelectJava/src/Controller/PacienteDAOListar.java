package Controller;

import Model.PacienteListar;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PacienteDAOListar {
    private Connection con;
    private PreparedStatement cmd;

    public PacienteDAOListar(){
        this.con = Conexao.Conectar();
    }
    
    public List<PacienteListar> listar(){
        try {
            String sql = "select * from paciente order by id";
            cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();
            
            List<PacienteListar> lista = new ArrayList<>();
            while(rs.next()){
                PacienteListar p = new PacienteListar();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPeso(rs.getFloat("peso"));
                p.setAltura(rs.getFloat("altura"));
                
                lista.add(p); 
        } 
            return lista;
       }
        catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
                return null;
                }
        finally{
            Conexao.Desconectar(con);
        }
        }
    
    public List<PacienteListar> pesquisarPorNome(String nome){
        try{
            String sql = "select * from paciente where nome like ? order by nome;";
            cmd = con.prepareStatement(sql);
            cmd.setString(1, "%" + nome + "%");
            
            ResultSet rs = cmd.executeQuery();
            List<PacienteListar> lista = new ArrayList<>();
            
            while(rs.next()){
                PacienteListar p = new PacienteListar();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPeso(rs.getFloat("peso")); 
                p.setAltura(rs.getFloat("altura"));
                
                lista.add(p);
            }
            return lista;
        }
        catch (Exception e){
            System.out.println("ERRO: " + e.getMessage());
            return null;
        }
        finally{
            Conexao.Desconectar(con);
        }
    }
}